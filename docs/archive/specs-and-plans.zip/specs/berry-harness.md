# Berry harness

The data image under `firmware/gardener/data` is compiled by the device at boot, so `arduino.py`
never sees it: a typo in a `.be` file costs a build, an upload and a serial console to find. The
harness in [tools/berry/](../../tools/berry) compiles and runs the whole image on the host instead,
against the vendored VM the firmware ships, and exits non-zero when a file fails to compile, a
registration does not look like a routine, or a page does not survive being driven.

## The parts

| File | What it is |
| --- | --- |
| `check.py` | the build and the command line: compiles the VM, links the host app, runs it |
| `main.cpp` | loads the files in the device's order and calls the checks |
| `host/BitmapPanel.h`, `host/BitmapPanel.cpp` | the panel: a 128 x 64 one-bit frame the session's canvas draws into through the same `gfx::DisplayDevice` the firmware uses |
| `host/HarnessSession.h` | the device composed as the firmware composes it, over that panel instead of the glass |
| `harness.be` | the driver's bookkeeping: the log, the error count, the routine count the summary prints, and the routine keys the memory report walks |
| `driver.be` | the smoke walk: the drive, the settings walk, and the scene re-entry |
| `tests/suite.be` | the suite framework: `test()`, the assertions, `drive`, the runner |
| `tests/*.test.be` | the suites, one file per concern, each registering named cases |

`check.py` builds `libraries/berry` with the firmware's own `berry_conf.h`, so the host VM has the
device's 32-bit ints, single-precision reals and `BE_STACK_TOTAL_MAX` slot limit. Objects and the
linked binary land in `tools/berry/build/`, which is ignored; a `.be` edit reuses them and only
compiles and loads.

## Running it

```powershell
python tools/berry/check.py                              # compile, load and drive the image
python tools/berry/check.py --compile                    # compile and load only
python tools/berry/check.py --art interval --seconds 60  # animate a page instead of driving it
python tools/berry/check.py --scene browser              # draw one of the device's own scenes
python tools/berry/check.py --tests                      # run the test suites, a GIF per case
python tools/berry/check.py --test ramped_static         # run one suite (or part of one)
python tools/berry/check.py --memory                     # the image's own boot, file by file
```

| Flag | Default | Meaning |
| --- | --- | --- |
| `--compile` | off | stop after compiling and loading every file |
| `--data DIR` | `firmware/gardener/data` | another data image, such as a scratch copy |
| `--no-cache` | off | rebuild the vendored VM objects |
| `--art NAME` | — | draw that routine and save an animation of it instead of driving |
| `--scene NAME` | — | draw that device scene — `home`, `browser` or `system` — and save an animation |
| `--seconds N` | `0` | with `--art` or `--scene`, run N seconds of virtual time first |
| `--sets N` | `12` | with `--art`, activate with N sets; `0` keeps the routine's own count |
| `--ceiling-kpa KPA` | `70` | the deepest depth the model chamber reaches |
| `--out PATH` | `build/<name>.gif` | where the GIF animation goes |
| `--tests` | off | run the test suites instead of the smoke walk |
| `--test NAME` | — | run only the cases whose full name contains NAME (implies `--tests`) |
| `--memory` | off | boot the image with no driver and no suites, and report what it holds |
| `--verbose` | off | print each compiler command |

The last line says how much loaded — `12 of 12 files loaded, check passed` — and the exit code is 0
only when every file compiled, every registration looked like a routine, and every page ran. In
`--tests` mode the same contract holds for the suites: `13 passed, 0 failed`, with `suites passed`.

## The load order

1. the image, in two parts:
   1. the files `/system/order` names, in the order it names them
   2. `/routines/*.be`, alphabetical
2. `harness.be`
3. `driver.be`

The order is not a preference. Berry resolves a global name when it **compiles** a file, so a file
may name only what an earlier file defined, and that reaches inside method bodies. A class a later
file needs has to be a global by the time the earlier file is compiled.

That is what `/system` is: the records the native calls answer with, the components and the scene
every page is written against, the settings view, and the registry. Its files do not sort into their
order, so `/system/order` states it — a path per line relative to `/system`, `#` for a comment, and
`components/text.be` beside `scene.be` for a file in a subfolder. A `.be` file in one of the folders
the order names, and not named by it, is reported as an error and not loaded. The routines load after
it, alphabetically.

In `--tests` mode two more load after those three: `tests/suite.be`, then `tests/*.test.be` in
alphabetical order. A suite can name every routine, module and `harness` drive because the whole
image is already compiled by then.

## What the harness provides

The records `unit`, `links`, `jingle`, `point` and `bounds` — declared in `/system/records.be`,
which the image loads before anything else — and the two native modules a routine calls:

| Module | On the host |
| --- | --- |
| `vacuum` | the machine: `state()`, the target and current pressure, the two bounds, `clamp()`, `start()`, `stop()` and `reset()` |
| `screen` | the drawing a page describes: every call answers a `draw` record, and a face name is held to the library's own table |
| `device` | the unit, the jingle selection and library, the piezo counting sounds rather than playing them, a press queue, the clock, the log, the reboot and reset requests, and `device.config` over `/cfg`, with `harness.writes()` counting the writes |

The registry the browser draws and the scene stack it pushes onto are not native: `/system/registry.be`
defines the global `routines` instance and `/system/ux.be` the global `ux`, which the driver and the
suites reach the same way a scene does.

The machine model is what a preview moves against. It starts at 0 kPa, pulls at 3 kPa/s, settles a
target when it is within 0.2 kPa of it, vents at 40 kPa/s, refuses a target below 5 kPa and caps at
the ceiling `--ceiling-kpa` sets, 70 kPa by default. One beat is 250 ms of virtual time.

### What it holds in memory

`harness.mem()` answers the VM's heap in bytes, read after a collection, so the figure is what the
image and the page under test keep rather than the garbage they have not dropped yet. It counts the
VM struct and everything the interpreter allocates through `be_realloc`: the value, call and
exception stacks, the globals, and every GC object, with a block of 32 bytes or less billed at its
requested size rather than its pool slot. `harness.mem_peak()` answers the largest such figure
sampled at any beat of the run so far.

The boot is sampled where the loader crosses into the host: the check's file system is read once per
image file, and the heap is read there, so the figures are the image's own and not the harness's.
Three of them, printed by a `--tests` run and by `--memory`:

```
[I] mem: vm <bytes> B, framework <bytes> B, image <bytes> B
```

`vm` is the interpreter with its native modules before any image file; `framework` is the heap once
`/system` has loaded; `image` is the heap once `/routines` has loaded and the root scene is built —
what the panel holds at boot. `/system` is a fixed cost of every page, so the difference between
`framework` and `image` is what the pages themselves cost.

`--memory` takes the same boot and stops there: no harness module, no driver, no suites, and then one
line per image file and one for the root scene, which is what each file's compilation added.

```
[I] mem: /system/home.be <bytes> B
[I] mem: /routines/5_ramped_static.be <bytes> B
[I] mem: root scene <bytes> B
```

The figures are the host's, under the device's `berry_conf.h`. A host pointer is 8 bytes and a
`bvalue` 16 where the S3's is 8, so the same image bills here roughly twice what it does on the
board: it is an upper bound on the board, not the board's figure. The board's own free heap is not
something the check can see, and the firmware's static RAM is the build's figure.

## The frame and its pictures

`--art` and `--scene` run the real page and save what it drew as an animated GIF, one frame per
beat at the panel's 128 x 64, paper and ink, each held for a second so the run reads slowly. The
GIF is enlarged 2 x to 256 x 128 by `kRenderScale` in the GIF writer — nearest neighbour, because
the picture is one bit. The frame delay is `kGifDelayCs`, one line to change to slow the whole
animation down or speed it up. The drawing is not an approximation of the driver's: the host draws
through the same Gfx library and the same canvas-and-device pair the device does, over
`BitmapPanel` in place of the SH1106, so the shapes, the text metrics and the compiled faces are
the ones a page gets on the glass. `BitmapPanel::packFrame` is the only difference — it hands the
one-bit frame to the GIF writer instead of to a bus.

A captured GIF also carries the gesture that drove it: each press the driver injects is shown as a
full-width strip across the top of the frame it lands on — the key and its form, `OK`, `OK×2`,
`CANCEL 5s` — so a tutorial can show the button as the viewer watches the run. The strip is a
host-only callout drawn over the captured frame; the page and the band never see it. It stays
for one beat, behind `kGestureCalloutBeats` in `tools/berry/host/GestureCallout.h`, which is the
one line to change to keep the key on screen longer.

The host compiles `libraries/Gfx` alongside the firmware's own sources, so the harness draws with
the library's real code: there is no installed copy of the drawing code to find and no shim.

Saving keeps the band the `ux` component draws: rows 52 to 63 are the device's own status row — the
unit, the serial and Bluetooth icons, the run-state icon and the battery — over whatever the page
put there.

A suite's frames are the exception. The runner marks the band once for the whole run with
`harness.mark_overlay(top, rows)`, so every frame a case captures — animation or still — carries a
hashed box over those rows: cleared to paper, outlined, and hatched diagonally in ink. The band is
the panel's own and no case draws it, so a test picture is a picture of the page the case drove, and
the box says where that page ends. `--art`, `--scene` and `--component` leave the band as the device
draws it.

The frame holds one bit and no display inversion, which is the panel's own depth and face.

## What the drive does

For every registered routine:

1. push with no settings map, then eight beats
2. one `ok:single`, then 400 s of virtual time, so a cycle's phases and its repeat are reached
3. an external stop notice, then every key's `single`, `up:double` with `back:single` to close the
   settings list it opened, and `cancel:double` — the routine has to survive all of it and hand the
   panel back

The settings view is walked first, through its whole key sequence: the drive opens it the way a
caller does — reading every value and applying the routine's rule — edits every row, and closes it
with Back, which is when the caller writes the set and the drive checks that every key landed.

## The test suites

The named checks live in `tests/*.test.be`, outside the data image so `arduino.py --task data`
never packs them. Each file sets `suite` to its own name, registers cases with `test(name, fn)` and
uses the helpers from `tests/suite.be`:

| Helper | What it is |
| --- | --- |
| `test(name, fn)` | register a case; `fn` is a function taking no arguments |
| `assert_true(cond, msg)` | raise when `cond` is false |
| `assert_eq(actual, expected, msg)` | raise when the values differ, with both in the message |
| `assert_nil(x, msg)`, `assert_not_nil(x, msg)` | raise on the wrong nil-ness |
| `drive(machine, beats)` | beat the harness and advance a machine, which is what a page's `tick()` does for it |
| `drive_until(machine, label, beats, pred)` | the same, until `pred()` is true, or raise naming `label` |

The runner executes every registered case (or those whose full `suite.case` name contains the
`--test` filter), each from a reset page, and reports one line per case: `[PASS] suite.case` or
`[FAIL] suite.case: assert: ...`, then `N passed, M failed`. A case that raises does not stop the
rest, and the run ends `suites passed` only when nothing failed.

Every case is also captured as an animation named `<stem>.<suite>.<case>.gif` — the stem is the
`--out` value with its `.gif` stripped, defaulting to `build/runs` — so a failing case leaves its
motion behind. Each frame has the overlay band hashed out, as above. A case that never beats has
nothing to animate and writes nothing.

A run also reports memory, and a figure never fails it. The runner records the heap the cases run
against — the image, the harness and the suites themselves — before the first case, and how far the
run reached above that after the last; `tests/memory.test.be` pushes each routine the image
registers, drives it for 400 s of virtual time — the drive's own budget for reaching a cycle's
phases and its repeat — and appends that page's own cost:

```
[I] mem: suites <bytes> B
[I] mem: <routine> +<bytes> B
[I] mem: peak +<bytes> B
```

A page is measured from the root scene, so its line is one page's cost rather than the stack's; it
also carries whatever the cases before it had already built, so a full run's pages read larger than
a `--test memory` run's. The routines walked are the registry as the image left it, which
`harness.be` keeps when it loads: a suite may register a routine of its own, and the report is about
the image's pages. Nothing about the outcome changes — the exit code and the `N passed, M failed`
line are what they were before the figures existed.

The suites cover what a walk cannot name: the jingle library, the System scene's unit, radio and
jingle rows, the settings model and its editors, the components and the layout, the overlay band,
the registry's hidden-routine rule, and what the interpreter holds once a page has settled.

The three run machines have a suite each — `home_machine`, `ramped_static_machine` and
`ramped_interval_machine` — which drive the machine itself: `configure()`, `handle_command()` and
`advance()` against the chamber, with no page, no gesture and no drawing. The pages that hold one are
covered by the page suites, which put a mock in place of `page.machine` and assert the calls the page
makes: the numbers it configures from its settings, the command each key means by phase, what it
draws, and what the closing settings list does. A page's mock declares the fields and methods that
page uses, so the page and its machine meet at a contract a case can read.

## Failing

A file that will not compile or load is reported the way the firmware reports it and the rest still
load:

```
[E] vm: routines/ramped_interval.be compile: ramped_interval.be:3: 'Unknown' undeclared
```

A check that fails says what it expected, prefixed with the page it was driving, and the run ends
with `check failed`. A failing suite case is a `[FAIL]` line carrying the assertion, and the run
ends `suites failed`. The VM's own failures — a missing routine, an unregistered name — are errors
of the image, not of the harness.
